package com.m.common.settings;

import java.io.Serializable;

public class SettingExtra extends SettingBean implements Serializable {

	private static final long serialVersionUID = 4608815242740722900L;

}
