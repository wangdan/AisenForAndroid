package com.m.support.sqlite.property;

public class Id extends Property {

}
