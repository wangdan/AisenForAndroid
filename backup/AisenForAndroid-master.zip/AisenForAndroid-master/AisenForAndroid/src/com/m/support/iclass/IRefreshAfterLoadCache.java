package com.m.support.iclass;

public interface IRefreshAfterLoadCache {

	public boolean refreshAfterLoadCache();
	
}
