package org.android.loader.core;

public interface BitmapOwner {

	public boolean canDisplay();
	
}
